package org.example.todo.server.protocol;

import java.util.List;

public class ListBoardsResponse {
    public List<BoardSummary> boards;
}
