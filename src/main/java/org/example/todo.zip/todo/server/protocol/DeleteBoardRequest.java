package org.example.todo.server.protocol;

public class DeleteBoardRequest {
    public String boardId;
}