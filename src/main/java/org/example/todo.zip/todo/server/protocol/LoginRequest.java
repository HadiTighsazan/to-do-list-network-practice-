package org.example.todo.server.protocol;

public class LoginRequest {
    public String username;
    public String password;
}
