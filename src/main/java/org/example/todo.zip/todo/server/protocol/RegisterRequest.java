package org.example.todo.server.protocol;

public class RegisterRequest {
    public String username;
    public String password;
}
