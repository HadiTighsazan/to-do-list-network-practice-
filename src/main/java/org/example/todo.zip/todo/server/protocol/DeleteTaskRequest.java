package org.example.todo.server.protocol;

public class DeleteTaskRequest {
    public String boardId;
    public String taskId;
}
