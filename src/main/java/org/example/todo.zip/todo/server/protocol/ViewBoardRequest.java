package org.example.todo.server.protocol;

public class ViewBoardRequest {
    public String boardId;
}
