package org.example.todo.server.protocol;

public class CreateBoardRequest {
    public String name;
}
