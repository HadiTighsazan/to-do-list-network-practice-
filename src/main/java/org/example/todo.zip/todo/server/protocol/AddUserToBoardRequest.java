package org.example.todo.server.protocol;

public class AddUserToBoardRequest {
    public String boardId;
    public String userId;
}
