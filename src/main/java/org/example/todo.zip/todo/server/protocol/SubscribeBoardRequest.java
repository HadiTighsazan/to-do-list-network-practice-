package org.example.todo.server.protocol;

public class SubscribeBoardRequest {
    public String boardId;
    public Integer udpPort;
}
